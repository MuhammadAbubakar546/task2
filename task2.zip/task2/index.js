


window.onscroll = function(){
let w =window.scrollY;
console.log(w);

if(document.documentElement.scrollTop>100){
     document.getElementById("head").classList.add("nextheader");

}else{

    document.getElementById("head").classList.remove("nextheader");
}

}


function button(){

let v=document.getElementById("box");
v.innerText="PURANA PAKISTAN";
}
document.getElementById("btn").addEventListener("click",button)